import React from 'react';
import { FaUserCircle, FaShoppingCart, FaSearch } from 'react-icons/fa';
//import logo from '../data/images/logo-DEE0KPH2.png'; // Make sure to replace this with the actual path to your logo image

const Navbar = () => (
  <div className="bg-white p-4 shadow-md flex justify-between items-center fixed top-0 left-0 w-full z-50">
    <div className="flex-1 flex justify-center relative">
      <div className="relative w-full max-w-md">
        <input
          type="text"
          placeholder="Search here..."
          className="p-2 pl-10 rounded border border-gray-300 w-full"
        />
        <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
      </div>
    </div>
    <div className="flex items-center flex-1 justify-end">
      <FaShoppingCart className="text-2xl ml-4 text-purple-500" />
      <FaUserCircle className="ml-4 text-blue-300" style={{ fontSize: '2.5rem' }} />
    </div>
  </div>
);

export default Navbar;
