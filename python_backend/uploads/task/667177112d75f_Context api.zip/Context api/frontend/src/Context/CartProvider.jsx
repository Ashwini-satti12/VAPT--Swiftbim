import React, { useState, useEffect } from "react";
import CartContext from "./CartContext";

const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([
    {
      id: 1,
      name: "Product 1",
      price: 100,
      image:
        "https://letsenhance.io/static/8f5e523ee6b2479e26ecc91b9c25261e/1015f/MainAfter.jpg",
    },
    {
      id: 2,
      name: "Product 2",
      price: 150,
      image:
        "https://buffer.com/library/content/images/2023/10/free-images.jpg",
    },
    {
      id: 3,
      name: "Product 3",
      price: 200,
      image: "https://th.bing.com/th/id/OIG3.5u5ZBGkvLQn1ELp4UqXH",
    },
    {
        id: 6,
        name: "Product 6",
        price: 350,
        image: "https://images.pexels.com/photos/1308881/pexels-photo-1308881.jpeg?auto=compress&cs=tinysrgb&w=600",
      }
    
  ]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setCart([
        {
          id: 4,
          name: "Product 4",
          price: 250,
          image: "https://images.pexels.com/photos/1133957/pexels-photo-1133957.jpeg?auto=compress&cs=tinysrgb&w=600",
        },
        {
          id: 5,
          name: "Product 5",
          price: 300,
          image: "https://images.pexels.com/photos/326055/pexels-photo-326055.jpeg?auto=compress&cs=tinysrgb&w=600",
        },
        {
          id: 6,
          name: "Product 6",
          price: 350,
          image: "https://images.pexels.com/photos/1308881/pexels-photo-1308881.jpeg?auto=compress&cs=tinysrgb&w=600",
        },
        {
            id: 2,
            name: "Product 2",
            price: 150,
            image:
              "https://images.pexels.com/photos/1043458/pexels-photo-1043458.jpeg?auto=compress&cs=tinysrgb&w=600",
          }
        
      ]);
    }, 5000);

    return () => clearTimeout(timer); // Cleanup the timer if the component unmounts
  }, []);

  return (
    <CartContext.Provider value={{ cart }}>
        {children}
    </CartContext.Provider>
  );
};

export default CartProvider;
