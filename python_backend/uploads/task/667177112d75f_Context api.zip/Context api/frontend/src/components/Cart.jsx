import React, { useContext } from "react";
import CartContext from "../Context/CartContext";
import '../index.css'; // Ensure this path is correct

const Cart = () => {
    const { cart } = useContext(CartContext);

    return (
        <div className="container mx-auto p-4 mt-16">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-2"> {/* Change the number of columns and reduce gap */}
                {cart.map((item) => (
                    <div 
                        key={item.id} 
                        className="border p-4 rounded-lg shadow-lg transform transition-transform duration-300 hover:scale-105 hover:shadow-2xl relative"
                        style={{
                            overflow: "hidden", // Ensure the image is clipped to the container
                            width: "300px", // Set a fixed width for the container
                            height: "300px", // Set a fixed height for the container
                            margin: "auto", // Center the cart item horizontally
                        }}
                    >
                        <img 
                            src={item.image} 
                            alt={item.name} 
                            className="absolute top-0 left-0 w-full h-full object-cover rounded-lg transition-transform duration-500 hover:-rotate-90" 
                            style={{
                                transformOrigin: "top left", // Set the transform origin to the top left corner
                            }}
                        />
                        <h2 className="text-xl font-semibold">{item.name}</h2>
                        <p className="text-gray-700">${item.price}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Cart;