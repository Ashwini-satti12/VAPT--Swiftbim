import React from "react";
import CartProvider from "./Context/CartProvider";
import Cart from "./components/Cart";
import Navbar from "./components/Navbar";

const App = () => {
    return (
        <CartProvider>
            <Navbar/>
            <Cart />
            <Cart />
        </CartProvider>
    );
};

export default App;
