import React, { useState } from "react";
import NoteContext from "./CartContext";

const NoteState = (props) => {
  const s1 = {
    name: "kailash",
    class: "10",
  };

  const [state, setState] = useState(s1);

  const update = () => {
    setTimeout(() => {
      setState({
        name: "Sumit",
        class: "12",
      });
    }, 1000);
  };

  return (
    <NoteContext.Provider value={{ state, update }}>
      {props.children}
    </NoteContext.Provider>
  );
};

export default NoteState;
